from chain import random_vector

__all__ = ['random_vector']